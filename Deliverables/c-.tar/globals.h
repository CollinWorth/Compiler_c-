#ifndef GLOBALS_H
#define GLOBALS_H

#include "tree.h"

#endif