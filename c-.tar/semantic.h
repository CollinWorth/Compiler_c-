#ifndef _SEMANTIC_H_
#define _SEMANTIC_H_

#include "tree.h"
#include "symbolTable.h"

void semanticAnalysis(TreeNode *t, SymbolTable *st);

#endif